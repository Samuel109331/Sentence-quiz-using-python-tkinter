from tkinter import ttk,messagebox
from tkinter import *
import random
import googletrans,time


def submit(value):
    global randSen,randLang,question,samplequest,choices,quiz,choice1,choice2,choice3,choice4,questions
    correct = googletrans.Translator().translate(randSen,dest=randLang).text
    if value == correct:
        randSen = random.choice(questions)
        question = f'What is the meaning of {randSen} in {randLang}'
        samplequest = random.sample(questions,4)
        choices = [googletrans.Translator().translate(i,dest=randLang).text for i in samplequest]
        choices.insert(random.randint(0,3),googletrans.Translator().translate(randSen,dest=randLang).text)
        quiz.config(text=question.replace('\n',' '))
        choice1.config(text=choices[0],value=choices[0])
        choice2.config(text=choices[1],value=choices[1])
        choice3.config(text=choices[2],value=choices[2])
        choice4.config(text=choices[3],value=choices[3])
    else:
        messagebox.showerror("Incorrect answer","Your answer is incorrect!")




        


win = Tk()

answer = StringVar(win)
answer.set(None)

with open('sentences.txt','r') as file:
    questions = file.readlines()
randSen = random.choice(questions)
randLang= 'spanish'
# random.choice([j for i,j in googletrans.LANGUAGES.items()])


question = f'What is the meaning of {randSen} in {randLang}'
samplequest = random.sample(questions,4)

choices = [googletrans.Translator().translate(i,dest=randLang).text for i in samplequest]

choices.insert(random.randint(0,3),googletrans.Translator().translate(randSen,dest=randLang).text)

quiz = ttk.Label(win,text=question.replace('\n',' '))
quiz.grid(row=0,column=0,sticky=W)

choice1 = ttk.Radiobutton(win,text=choices[0],value=choices[0],variable=answer,command= lambda : submit(choices[0]))
choice2 = ttk.Radiobutton(win,text=choices[1],value=choices[1],variable=answer,command= lambda : submit(choices[1]))
choice3 = ttk.Radiobutton(win,text=choices[2],value=choices[2],variable=answer,command= lambda : submit(choices[2]))
choice4 = ttk.Radiobutton(win,text=choices[3],value=choices[3],variable=answer,command= lambda : submit(choices[3]))

choice1.grid(row=1,column=0,sticky=W)
choice2.grid(row=2,column=0,sticky=W)
choice3.grid(row=3,column=0,sticky=W)
choice4.grid(row=4,column=0,sticky=W)

win.mainloop()

